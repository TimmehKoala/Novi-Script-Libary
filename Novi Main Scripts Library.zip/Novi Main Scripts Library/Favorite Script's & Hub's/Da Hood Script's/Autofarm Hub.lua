loadstring(game:HttpGet("https://pastebin.com/raw/74VJ07iY", true))()

-- https://www.roblox.com/groups/11906512/RaceCodex-Community#!/about

-- You have to join this group for this script to work, it's ass