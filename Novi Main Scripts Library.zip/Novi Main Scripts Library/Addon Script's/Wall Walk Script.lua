loadstring(game:HttpGet("https://pastebin.com/raw/zXk4Rq2r"))()
