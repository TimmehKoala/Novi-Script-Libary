-- Made by Gui to Lua
-- Version: 3.2
-- By Farrel#2469

-- Instances:

local Speedcheats = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local TextLabel_2 = Instance.new("TextLabel")
local TextLabel_3 = Instance.new("TextLabel")
local Needed = Instance.new("Folder")
local TextButton = Instance.new("TextButton")
local TextBox = Instance.new("TextBox")
local TextButton_2 = Instance.new("TextButton")
local TextBox_2 = Instance.new("TextBox")
local Speed = Instance.new("TextLabel")
local TextLabel_4 = Instance.new("TextLabel")
local Value1 = Instance.new("NumberValue")
local Value2 = Instance.new("NumberValue")

--Properties:

Speedcheats.Name = "Speed cheats"
Speedcheats.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
Speedcheats.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = Speedcheats
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.Position = UDim2.new(0.0355781242, 0, 0.0477137007, 0)
Frame.Size = UDim2.new(0, 387, 0, 192)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.Position = UDim2.new(0.0368487909, 0, 0.163021863, 0)
TextLabel.Size = UDim2.new(0, 200, 0, 50)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Speed Editor"
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextScaled = true
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true

TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.Position = UDim2.new(0.0355555564, 0, 0.473958343, 0)
TextLabel_2.Size = UDim2.new(0, 200, 0, 50)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.Text = "Press E for more speed"
TextLabel_2.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.TextScaled = true
TextLabel_2.TextSize = 14.000
TextLabel_2.TextWrapped = true

TextLabel_3.Parent = Frame
TextLabel_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_3.Position = UDim2.new(0.0355555564, 0, 0.739583313, 0)
TextLabel_3.Size = UDim2.new(0, 200, 0, 43)
TextLabel_3.Font = Enum.Font.SourceSans
TextLabel_3.Text = "Press Q for less speed"
TextLabel_3.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_3.TextScaled = true
TextLabel_3.TextSize = 14.000
TextLabel_3.TextWrapped = true

Needed.Name = "Needed"
Needed.Parent = Frame

TextButton.Name = "+"
TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton.Position = UDim2.new(0.620155096, 0, 0.317708343, 0)
TextButton.Size = UDim2.new(0, 125, 0, 30)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "Set E Speed"
TextButton.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton.TextScaled = true
TextButton.TextSize = 14.000
TextButton.TextWrapped = true

TextBox.Parent = TextButton
TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextBox.Position = UDim2.new(0, 0, -1.00520837, 0)
TextBox.Size = UDim2.new(0, 125, 0, 30)
TextBox.ClearTextOnFocus = false
TextBox.Font = Enum.Font.SourceSans
TextBox.PlaceholderText = "Value"
TextBox.ShowNativeInput = false
TextBox.Text = ""
TextBox.TextColor3 = Color3.fromRGB(0, 0, 0)
TextBox.TextScaled = true
TextBox.TextSize = 14.000
TextBox.TextWrapped = true

TextButton_2.Name = "-"
TextButton_2.Parent = Frame
TextButton_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_2.Position = UDim2.new(0.620155096, 0, 0.734375, 0)
TextButton_2.Size = UDim2.new(0, 125, 0, 30)
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.Text = "Set Q Speed"
TextButton_2.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_2.TextScaled = true
TextButton_2.TextSize = 14.000
TextButton_2.TextWrapped = true

TextBox_2.Parent = TextButton_2
TextBox_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextBox_2.Position = UDim2.new(0, 0, -1, 0)
TextBox_2.Size = UDim2.new(0, 125, 0, 29)
TextBox_2.ClearTextOnFocus = false
TextBox_2.Font = Enum.Font.SourceSans
TextBox_2.PlaceholderText = "Value"
TextBox_2.ShowNativeInput = false
TextBox_2.Text = ""
TextBox_2.TextColor3 = Color3.fromRGB(0, 0, 0)
TextBox_2.TextScaled = true
TextBox_2.TextSize = 14.000
TextBox_2.TextWrapped = true

Speed.Name = "Speed"
Speed.Parent = Frame
Speed.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Speed.Position = UDim2.new(1, 0, 0, 0)
Speed.Size = UDim2.new(0, 152, 0, 50)
Speed.Font = Enum.Font.SourceSans
Speed.Text = "Speed"
Speed.TextColor3 = Color3.fromRGB(0, 0, 0)
Speed.TextScaled = true
Speed.TextSize = 14.000
Speed.TextWrapped = true

TextLabel_4.Parent = Frame
TextLabel_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_4.Position = UDim2.new(0, 0, 1, 0)
TextLabel_4.Size = UDim2.new(0, 387, 0, 37)
TextLabel_4.Font = Enum.Font.SourceSans
TextLabel_4.Text = "Press L to Toogle Speed Editor"
TextLabel_4.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_4.TextScaled = true
TextLabel_4.TextSize = 14.000
TextLabel_4.TextWrapped = true

Value1.Parent = Needed
Value1.Name = "Value +"
Value1.Value = "1"

Value2.Parent = Needed
Value2.Name = "Value -"
Value2.Value = "1"

-- Scripts:

local function UAPPNV_fake_script() -- Needed.LocalScript 
 local script = Instance.new('LocalScript', Needed)

 game:GetService("UserInputService").InputBegan:Connect(function(inp, gameProcessed)
  local plr = game.Players.LocalPlayer
  if inp.KeyCode == Enum.KeyCode.E then
   plr.Character.Humanoid.WalkSpeed = plr.Character.Humanoid.WalkSpeed + script.Parent.Parent.Needed["Value +"].Value
  end
 end)
 game:GetService("UserInputService").InputBegan:Connect(function(inp, gameProcessed)
  local plr = game.Players.LocalPlayer
  if inp.KeyCode == Enum.KeyCode.Q then
   plr.Character.Humanoid.WalkSpeed = plr.Character.Humanoid.WalkSpeed - script.Parent.Parent.Needed["Value -"].Value
  end
 end)
end
coroutine.wrap(UAPPNV_fake_script)()
local function TTUGO_fake_script() -- TextButton.LocalScript 
 local script = Instance.new('LocalScript', TextButton)

 script.Parent.MouseButton1Click:Connect(function()
  script.Parent.Parent.Needed["Value +"].Value = script.Parent.TextBox.Text
 end)
end
coroutine.wrap(TTUGO_fake_script)()
local function DOJLZOF_fake_script() -- TextButton_2.LocalScript 
 local script = Instance.new('LocalScript', TextButton_2)

 script.Parent.MouseButton1Click:Connect(function()
  script.Parent.Parent.Needed["Value -"].Value = script.Parent.TextBox.Text
 end)
end
coroutine.wrap(DOJLZOF_fake_script)()
local function IZSF_fake_script() -- Speed.LocalScript 
 local script = Instance.new('LocalScript', Speed)

 wait(1)
 while true do
  script.Parent.Text = "Speed : "..game.Players.LocalPlayer.Character.Humanoid.WalkSpeed
  wait(0.1)
 end
end
coroutine.wrap(IZSF_fake_script)()
local function MTSUL_fake_script() -- TextLabel_4.LocalScript 
 local script = Instance.new('LocalScript', TextLabel_4)

 game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
  if input.KeyCode == Enum.KeyCode.L then
   if script.Parent.Parent.Visible == true then
    script.Parent.Parent.Visible = false
   else
    script.Parent.Parent.Visible = true
   end
  end
 end)
end
coroutine.wrap(MTSUL_fake_script)()