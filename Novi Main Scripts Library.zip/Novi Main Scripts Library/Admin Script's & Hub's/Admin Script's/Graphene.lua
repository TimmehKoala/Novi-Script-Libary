pcall(function() loadstring(game:GetObjects("rbxassetid://10572164822")[1].Source)() end)
