loadstring(game:HttpGet("https://pastebin.com/raw/ZpSQug4D", true))()





