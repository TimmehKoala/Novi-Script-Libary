-- if you play any games with good antiexploit that stops speed scripts you might wanna use this. (THIS DOSENT BYPASS EVERY GAME)

-- change the speed on where it says local walkspeed and feel free to add globals to it

local walkSpeed = 32



local gmt = getrawmetatable(game)

setreadonly(gmt, false)

local oldindex = gmt.__index

gmt.__index = newcclosure(function(self,b)

if b == "WalkSpeed" then

return 16

end

return oldindex(self,b)

end)



game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed = walkSpeed