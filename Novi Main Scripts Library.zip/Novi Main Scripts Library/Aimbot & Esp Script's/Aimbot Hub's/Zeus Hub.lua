loadstring(game:HttpGet(("https://pastebin.com/raw/QM211VHT"),true))()
