loadstring(game:HttpGet('https://raw.githubusercontent.com/GhostPlayer352/Freeze-Tool-Test.md/main/RTX%20Gui%20Hub.md'))()
