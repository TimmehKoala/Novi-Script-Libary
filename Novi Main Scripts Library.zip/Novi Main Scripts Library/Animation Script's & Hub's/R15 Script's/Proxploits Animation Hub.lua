--  ,ggggggggggg,                      ,ggg,          ,gg                                                        
-- dP"""88""""""Y8,                   dP"""Y8,      ,dP'              ,dPYb,                      I8             
-- Yb,  88      `8b                   Yb,_  "8b,   d8"                IP'`Yb                      I8             
--  `"  88      ,8P                    `""    Y8,,8P'                 I8  8I               gg  88888888          
--      88aaaad8P"                             Y88"                   I8  8'               ""     I8             
--      88"""""    ,gggggg,    ,ggggg,        ,888b       gg,gggg,    I8 dP    ,ggggg,     gg     I8      ,g,    
--      88         dP""""8I   dP"  "Y8ggg    d8" "8b,     I8P"  "Yb   I8dP    dP"  "Y8ggg  88     I8     ,8'8,   
--      88        ,8'    8I  i8'    ,8I    ,8P'    Y8,    I8'    ,8i  I8P    i8'    ,8I    88    ,I8,   ,8'  Yb  
--      88       ,dP     Y8,,d8,   ,d8'   d8"       "Yb, ,I8 _  ,d8' ,d8b,_ ,d8,   ,d8'  _,88,_ ,d88b, ,8'_   8) 
--     88       8P      `Y8P"Y8888P"   ,8P'          "Y8PI8 YY88888P8P'"Y88P"Y8888P"    8P""Y888P""Y88P' "YY8P8P
--                                                        I8                                                     
--                                                        I8                                                     
--         https://linktr.ee/proxploits                   I8                                                     
--                                                        I8                https://discord.gg/X9Q2fcf                                 
--                                                        I8                                                     
--                                                        I8                                                     

-- Script (ENERGIZER ANIM GUI): 
loadstring(game:HttpGet("https://pastebin.com/raw/RmD3qNp7", true))()