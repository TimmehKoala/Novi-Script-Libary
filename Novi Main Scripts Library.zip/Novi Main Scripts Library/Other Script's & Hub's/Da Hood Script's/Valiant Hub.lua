loadstring(game:HttpGet("https://raw.githubusercontent.com/cypherdh/Valiant/main/script"))()
